import { motion } from "motion/react";

export default function App() {
  const links = [
    { label: "Experience", url: "https://www.judahv.site/experience/" },
    { label: "Trajectory", url: "https://www.judahv.site/trajectory/" },
    { label: "Education", url: "https://www.judahv.site/education/" },
  ];

  return (
    <div className="relative min-h-screen w-full bg-black font-[family-name:var(--font-designer)] flex flex-col justify-center overflow-hidden">
      
      {/* Animated Background Layers - Moving Faster Now */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Deep Red Orb */}
        <motion.div
          animate={{
            x: ["-10%", "25%", "-15%", "-10%"],
            y: ["-10%", "25%", "5%", "-10%"],
            scale: [1, 1.3, 0.7, 1],
          }}
          transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-1/4 left-1/4 w-[45vw] h-[45vw] max-w-[700px] max-h-[700px] bg-red-600 rounded-full mix-blend-screen opacity-80 blur-[80px]"
        />
        {/* Soft White Orb */}
        <motion.div
          animate={{
            x: ["25%", "-15%", "15%", "25%"],
            y: ["20%", "0%", "-20%", "20%"],
            scale: [0.7, 1.3, 0.9, 0.7],
          }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-1/4 right-1/4 w-[40vw] h-[40vw] max-w-[600px] max-h-[600px] bg-white rounded-full mix-blend-screen opacity-30 blur-[90px]"
        />
        {/* Dark Ruby Pulse */}
        <motion.div
          animate={{
            scale: [0.8, 1.6, 0.8],
            opacity: [0.3, 0.7, 0.3],
          }}
          transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[60vw] h-[60vw] bg-[#8B0000] rounded-full mix-blend-screen blur-[120px]"
        />
      </div>

      {/* Grain Overlay - Subtle & Visible high-quality grain */}
      <div className="absolute inset-0 bg-noise mix-blend-overlay opacity-35 contrast-125 pointer-events-none" />

      {/* Content Links */}
      <div className="relative z-10 w-full h-[90vh] py-16 px-6 md:px-16 flex flex-col justify-between">
        {links.map((link, index) => (
          <motion.a
            key={link.label}
            href={link.url}
            initial={{ opacity: 0, y: 20, filter: "blur(4px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            transition={{ delay: index * 0.15, duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className={`group block w-full relative flex ${
              index === 0 ? "justify-start" : index === 1 ? "justify-center" : "justify-end"
            }`}
          >
            <motion.span 
              whileHover={{ scale: 1.05 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
              className="block text-[#f0f0f0] font-[900] text-[12vw] leading-[0.8] tracking-[-0.04em] uppercase transition-colors duration-300 hover:text-red-600 mix-blend-plus-lighter origin-center"
            >
              {link.label}
            </motion.span>
          </motion.a>
        ))}
      </div>

      {/* Subtle site identifier */}
      <div className="fixed bottom-6 left-6 z-20 pointer-events-none">
        <span className="text-[10px] uppercase tracking-[0.4em] text-white opacity-40 font-medium">
          judahv.site
        </span>
      </div>
    </div>
  );
}
