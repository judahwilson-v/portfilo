import { motion } from "motion/react";

export default function App() {
  const links = [
    { label: "Experience", url: "https://www.judahv.site/experience/" },
    { label: "Trajectory", url: "https://www.judahv.site/trajectory/" },
    { label: "Education", url: "https://www.judahv.site/education/" },
  ];

  return (
    <div className="min-h-screen flex flex-col justify-center px-8 md:px-24 bg-[#f5f5f4] selection:bg-black selection:text-white">
      <div className="flex flex-col gap-6 md:gap-8">
        {links.map((link, index) => (
          <motion.a
            key={link.label}
            href={link.url}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1, duration: 0.8, ease: "circOut" }}
            className="group block w-fit"
          >
            <span className="font-serif text-6xl md:text-8xl lg:text-[10rem] leading-[0.8] tracking-tighter uppercase transition-all duration-500 group-hover:italic group-hover:pl-8">
              {link.label}
            </span>
          </motion.a>
        ))}
      </div>

      {/* Subtle site identifier in corner */}
      <div className="fixed bottom-8 left-8">
        <span className="font-sans text-[10px] uppercase tracking-[0.4em] opacity-20">
          judahv.site
        </span>
      </div>
    </div>
  );
}
